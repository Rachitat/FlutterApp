import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_spinkit/flutter_spinkit.dart';

class DogPage extends StatefulWidget {
  const DogPage({super.key});

  @override
  State<DogPage> createState() => _DogPageState();
}

class _DogPageState extends State<DogPage> {
  String? imageUrl;
  bool loading = false;

  /// STEP 1: Call API
  Future<void> fetchDog() async {
    setState(() => loading = true);

    /// STEP 2: Send request
    final response = await http.get(
      Uri.parse("https://dog.ceo/api/breeds/image/random"),
    );

    /// STEP 3: Convert JSON
    final data = jsonDecode(response.body);

    /// STEP 4: Extract image URL
    setState(() {
      imageUrl = data["message"];
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchDog(); // auto load
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Random Dog 🐶")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            loading
                ? const SpinKitCircle(color: Colors.blue, size: 60)
                : imageUrl != null
                ? Image.network(imageUrl!, height: 250)
                : const Text("No Image"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: fetchDog,
              child: const Text("Load New Dog"),
            ),
          ],
        ),
      ),
    );
  }
}
