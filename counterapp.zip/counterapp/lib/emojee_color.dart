import 'package:flutter/material.dart';
import 'dart:math';

class EmojiMoodCounterPage extends StatefulWidget {
  const EmojiMoodCounterPage({super.key});

  @override
  State<EmojiMoodCounterPage> createState() => _EmojiMoodCounterPageState();
}

class _EmojiMoodCounterPageState extends State<EmojiMoodCounterPage> {
  int _counter = 0;
  Color _backgroundColor = Colors.white;

  final List<String> _emojis = ['😐', '🙂', '😄', '🤩', '🥳', '🔥'];

  void _incrementCounter() {
    setState(() {
      _counter++;
      _backgroundColor = _getRandomColor();
    });
  }

  Color _getRandomColor() {
    final random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  String _getEmojiForCounter(int count) {
    if (count < 3) return _emojis[0];
    if (count < 6) return _emojis[1];
    if (count < 9) return _emojis[2];
    if (count < 12) return _emojis[3];
    if (count < 15) return _emojis[4];
    return _emojis[5];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,
      appBar: AppBar(
        title: const Text("Emoji Mood Counter"),
        backgroundColor: Colors.black87,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Mood Emoji:',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 20),
            Text(
              _getEmojiForCounter(_counter),
              style: const TextStyle(fontSize: 80),
            ),
            const SizedBox(height: 30),
            Text(
              'Counter: $_counter',
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: _incrementCounter,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                padding:
                const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              ),
              child: const Text(
                'Increase',
                style: TextStyle(fontSize: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
