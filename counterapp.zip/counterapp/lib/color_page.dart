import 'package:flutter/material.dart';
import 'package:random_color/random_color.dart';

class ColorPage extends StatefulWidget {
  const ColorPage({super.key});

  @override
  State<ColorPage> createState() => _ColorPageState();
}

class _ColorPageState extends State<ColorPage> {
  Color bg = Colors.white;

  void changeColor() {
    setState(() {
      bg = RandomColor().randomColor();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(title: const Text("Color Generator 🎨")),
      body: Center(
        child: ElevatedButton(
          onPressed: changeColor,
          child: const Text("Change Color"),
        ),
      ),
    );
  }
}
