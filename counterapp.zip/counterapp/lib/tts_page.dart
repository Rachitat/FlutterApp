import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class TTSPage extends StatefulWidget {
  const TTSPage({super.key});

  @override
  State<TTSPage> createState() => _TTSPageState();
}

class _TTSPageState extends State<TTSPage> {
  final FlutterTts tts = FlutterTts();
  final TextEditingController controller = TextEditingController();

  speak() async {
    await tts.speak(controller.text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Text To Speech 🗣️")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: "Enter text",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: speak, child: const Text("Speak")),
          ],
        ),
      ),
    );
  }
}
