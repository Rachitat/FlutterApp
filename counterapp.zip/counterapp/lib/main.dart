import 'package:flutter/material.dart';

import 'dog_page.dart';
import 'dice_page.dart';
import 'tts_page.dart';
import 'color_page.dart';
import 'emojee_color.dart';

void main() {
  runApp(const FunApps());
}

class FunApps extends StatelessWidget {
  const FunApps({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Fun Apps',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeMenu(),
    );
  }
}

class HomeMenu extends StatelessWidget {
  const HomeMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Fun Apps Menu'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _menuButton(
            context,
            'Dog App',
            const DogPage(),
          ),
          _menuButton(
            context,
            'Dice App',
            const DicePage(),
          ),
          _menuButton(
            context,
            'Text To Speech',
            const TTSPage(),
          ),
          _menuButton(
            context,
            'Random Color',
            const ColorPage(),
          ),
          _menuButton(
            context,
            'Emoji Mood Counter',
            const EmojiMoodCounterPage(),
          ),
        ],
      ),
    );
  }

  Widget _menuButton(BuildContext context, String title, Widget page) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.all(16),
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => page),
          );
        },
        child: Text(
          title,
          style: const TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
